﻿public enum SeasonEnum
{
    Autumn = 1,
    Spring,
    Winter,
    Summer
}