﻿public enum DiscountEnum
{
    None,
    SecondVisit = 10,
    VIP = 20
}