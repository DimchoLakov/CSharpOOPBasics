﻿public interface ISoundProducable
{
    void ProduceSound();
}