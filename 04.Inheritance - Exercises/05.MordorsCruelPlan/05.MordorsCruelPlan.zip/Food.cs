﻿public abstract class Food
{
    private int foodHappiness;

    public abstract int FoodHappiness { get; }
}