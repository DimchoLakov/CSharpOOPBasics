﻿public class Melon : Food
{
    public override int FoodHappiness
    {
        get { return 1; }
    }
}