﻿public class Lembas : Food
{
    public override int FoodHappiness
    {
        get { return 3; }
    }
}