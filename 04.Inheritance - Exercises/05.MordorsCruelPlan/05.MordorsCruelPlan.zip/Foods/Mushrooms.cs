﻿public class Mushrooms : Food
{
    public override int FoodHappiness
    {
        get { return -10; }
    }
}