﻿public class HoneyCake : Food
{
    public override int FoodHappiness
    {
        get { return 5; }
    }
}