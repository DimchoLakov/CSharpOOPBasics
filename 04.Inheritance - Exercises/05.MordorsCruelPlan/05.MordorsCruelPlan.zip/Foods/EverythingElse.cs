﻿public class EverythingElse : Food
{
    public override int FoodHappiness
    {
        get { return -1; }
    }
}