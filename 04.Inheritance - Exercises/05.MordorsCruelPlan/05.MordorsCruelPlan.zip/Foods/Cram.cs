﻿public class Cram : Food
{
    public override int FoodHappiness
    {
        get { return 2; }
    }
}