﻿using System.Net.Http.Headers;

public class Apple : Food
{
    public override int FoodHappiness
    {
        get { return 1; }
    }
}