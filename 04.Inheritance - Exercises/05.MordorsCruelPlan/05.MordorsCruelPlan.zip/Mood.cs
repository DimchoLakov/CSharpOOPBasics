﻿public abstract class Mood
{
    private string moodType;

    public abstract string MoodType { get; }
}