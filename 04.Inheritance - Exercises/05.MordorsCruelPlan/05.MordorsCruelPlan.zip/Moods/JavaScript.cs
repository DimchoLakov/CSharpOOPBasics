﻿public class JavaScript : Mood
{
    public override string MoodType
    {
        get { return "JavaScript"; }
    }
}