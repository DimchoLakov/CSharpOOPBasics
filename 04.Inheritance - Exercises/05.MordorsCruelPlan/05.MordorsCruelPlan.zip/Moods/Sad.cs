﻿public class Sad : Mood
{
    public override string MoodType
    {
        get { return "Sad"; }
    }
}