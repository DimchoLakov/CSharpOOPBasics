﻿public class Angry : Mood
{
    public override string MoodType
    {
        get { return "Angry"; }
    }
}