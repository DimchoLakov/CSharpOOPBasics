﻿public class Happy : Mood
{
    public override string MoodType
    {
        get { return "Happy"; }
    }
}