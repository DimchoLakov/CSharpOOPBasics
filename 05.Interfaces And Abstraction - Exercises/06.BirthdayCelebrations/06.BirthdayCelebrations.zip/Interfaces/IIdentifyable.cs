﻿public interface IIdentifyable
{
    string Id { get; }
}