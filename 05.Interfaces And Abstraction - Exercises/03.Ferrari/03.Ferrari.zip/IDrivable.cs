﻿public interface IDrivable
{
    string Brakes();

    string Gas();
}