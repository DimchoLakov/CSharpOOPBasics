﻿public interface ISpecialisedSoldier : IPrivate
{
    string Corps { get; }
}