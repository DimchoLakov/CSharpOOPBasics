﻿using System;

public interface IBrowse
{
    string Browse(string url);
}