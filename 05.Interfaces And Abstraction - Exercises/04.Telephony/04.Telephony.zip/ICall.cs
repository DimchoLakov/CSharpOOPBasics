﻿public interface ICall
{
    string Call(string number);
}