﻿using System;

public interface IBirthable
{
    DateTime Birthday { get; }
}