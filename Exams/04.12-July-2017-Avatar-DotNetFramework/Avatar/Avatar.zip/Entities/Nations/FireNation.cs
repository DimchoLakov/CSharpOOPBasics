﻿public class FireNation : Nation
{
    public FireNation()
    {
    }

    public override string Name => "Fire";
}