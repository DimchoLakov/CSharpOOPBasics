﻿public class WaterNation : Nation
{
    public WaterNation()
    {
    }

    public override string Name => "Water";
}