﻿public class EarthNation : Nation
{
    public EarthNation()
    {
    }

    public override string Name => "Earth";
}