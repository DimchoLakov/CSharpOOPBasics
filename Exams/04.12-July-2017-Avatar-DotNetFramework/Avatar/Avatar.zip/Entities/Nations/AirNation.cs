﻿using System.Collections.Generic;

public class AirNation : Nation
{
    public AirNation()
    {
    }

    public override string Name => "Air";
}