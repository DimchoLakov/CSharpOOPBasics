﻿public class Backpack : Bag
{
    public Backpack() : base(DefaultCapacity)
    {
    }
}