﻿using System;

class Program
{
    static void Main()
    {

    }
}
